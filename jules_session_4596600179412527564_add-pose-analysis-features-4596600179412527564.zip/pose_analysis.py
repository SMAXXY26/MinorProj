import cv2
import mediapipe as mp
import numpy as np
import argparse
import os

def calculate_angle(a, b, c):
    """
    Calculates the angle at point b given points a, b, and c.
    Points are expected to be (x, y) coordinates.
    """
    a = np.array(a) # First
    b = np.array(b) # Mid
    c = np.array(c) # End
    
    radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
    angle = np.abs(radians*180.0/np.pi)
    
    if angle > 180.0:
        angle = 360-angle
        
    return angle

def main():
    parser = argparse.ArgumentParser(description='MediaPipe Pose Detection with Angle Calculation')
    parser.add_argument('--input', type=str, default='0', help='Input source: camera index (e.g. 0) or path to video/image file')
    parser.add_argument('--output', type=str, help='Path to save the output video/image')
    args = parser.parse_args()

    # Initialize MediaPipe Pose
    mp_pose = mp.solutions.pose
    mp_draw = mp.solutions.drawing_utils
    pose = mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)

    # Check if input is a camera index
    if args.input.isdigit():
        input_source = int(args.input)
    else:
        input_source = args.input

    cap = cv2.VideoCapture(input_source)
    if not cap.isOpened():
        print(f"Error: Could not open input source {args.input}")
        return

    # Get input properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps == 0 or fps is None:
        fps = 30
    
    is_image = False
    if not args.input.isdigit() and os.path.isfile(args.input):
        ext = os.path.splitext(args.input)[1].lower()
        if ext in ['.jpg', '.jpeg', '.png', '.bmp']:
            is_image = True

    # Initialize VideoWriter if output is specified for video
    writer = None
    if args.output and not is_image:
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        writer = cv2.VideoWriter(args.output, fourcc, fps, (width, height))

    # Check if we have a display
    has_display = "DISPLAY" in os.environ and os.environ["DISPLAY"] != ""

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Convert BGR (OpenCV) to RGB (MediaPipe)
        img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(img_rgb)

        # Draw landmarks and calculate angles
        if results.pose_landmarks:
            landmarks = results.pose_landmarks.landmark
            
            # Define joints to monitor
            joints = {
                "Left Elbow": [mp_pose.PoseLandmark.LEFT_SHOULDER, mp_pose.PoseLandmark.LEFT_ELBOW, mp_pose.PoseLandmark.LEFT_WRIST],
                "Right Elbow": [mp_pose.PoseLandmark.RIGHT_SHOULDER, mp_pose.PoseLandmark.RIGHT_ELBOW, mp_pose.PoseLandmark.RIGHT_WRIST],
                "Left Knee": [mp_pose.PoseLandmark.LEFT_HIP, mp_pose.PoseLandmark.LEFT_KNEE, mp_pose.PoseLandmark.LEFT_ANKLE],
                "Right Knee": [mp_pose.PoseLandmark.RIGHT_HIP, mp_pose.PoseLandmark.RIGHT_KNEE, mp_pose.PoseLandmark.RIGHT_ANKLE]
            }

            # Draw default landmarks
            mp_draw.draw_landmarks(
                frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                mp_draw.DrawingStyle(color=(0, 255, 0), thickness=2),
                mp_draw.DrawingStyle(color=(0, 0, 255), thickness=2)
            )

            # Calculate and display angles
            for joint_name, joint_points in joints.items():
                try:
                    # Get coordinates
                    p1 = landmarks[joint_points[0].value]
                    p2 = landmarks[joint_points[1].value]
                    p3 = landmarks[joint_points[2].value]

                    # Ensure visibility is high enough before calculating
                    if p1.visibility > 0.5 and p2.visibility > 0.5 and p3.visibility > 0.5:
                        a = [p1.x * width, p1.y * height]
                        b = [p2.x * width, p2.y * height]
                        c = [p3.x * width, p3.y * height]

                        angle = calculate_angle(a, b, c)

                        # Visualize angle
                        cv2.putText(frame, f"{int(angle)}", 
                                   tuple(np.multiply(b, [1, 1]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                except (AttributeError, IndexError):
                    # Skip if landmarks are missing or malformed
                    pass

        if writer:
            writer.write(frame)
        
        if is_image and args.output:
            cv2.imwrite(args.output, frame)

        if has_display:
            cv2.imshow('MediaPipe Pose', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
        if is_image:
            break

    cap.release()
    if writer:
        writer.release()
    if has_display:
        cv2.destroyAllWindows()
    pose.close()

if __name__ == "__main__":
    main()
